from django.contrib import admin
from .models import donateMoney

admin.site.register(donateMoney)
