Project Name : Feed Angels
Group Member : Md. Faisal Ahmed, Md. Rokibul Hasan

Old features:

* User can create an account.
* User login and authentication.
* Create an account as a Volunteer.
* Added Pickup Points and design page.

New feature:

* Added Password Reset Email functionality.
* User can search by District to see available Pickup point.(Query search functionality)
* User can donate money via card, bank or other online banking system.
* They can update his Profile information, profile picture etc.
* They can change his password. 
* They can see his profile and his donation history.

*** Also added Unit test methods.

Github link: https://github.com/RokibulHasan7/FeedAngels3